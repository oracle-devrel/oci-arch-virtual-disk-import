import io
import json
import logging

import os
from fdk import response

import requests
import oci
import traceback

def handler(ctx, data: io.BytesIO = None):
    logging.getLogger().info("Received new request")
    try:
        ### Get request data
        logging.getLogger().info(f'Data: {data.getvalue()}')
        body = json.loads(data.getvalue())
        bucket = body.get('data').get('additionalDetails').get('bucketName')
        namespace = body.get('data').get('additionalDetails').get('namespace')
        resource = body.get('data').get('resourceName')
        supported_formats = ["qcow2", "raw", "vdi", "vhdx", "vmdk"]

        if len(resource.lower().split(".")) < 2:
            logging.getLogger.info(f"Couldn't determine file extension using the file name: {resource.lower()}")
            return
        else:
            file_extension = resource.lower().split(".")[-1]
        if file_extension in supported_formats:
            ### Get environment variables
            airflow_api_endpoint = os.environ.get('AIRFLOW_API_ENDPOINT')
            airflow_username = os.environ.get('AIRFLOW_USERNAME')
            airflow_password = os.environ.get('AIRFLOW_PASSWORD')
            airflow_dag_id = os.environ.get('AIRFLOW_DAG_ID')
            signer = oci.auth.signers.get_resource_principals_signer()
            object_storage_client = oci.object_storage.ObjectStorageClient({}, signer=signer)
            head_object_response = object_storage_client.head_object(
                namespace_name=namespace,
                bucket_name=bucket,
                object_name=resource)
            obj_metadata = {k:v for k,v in head_object_response.headers.items() if k.startswith('opc-meta-')}
            if 'opc-meta-ad_number' in obj_metadata:
                ad_number = int(obj_metadata['opc-meta-ad_number'])
            else:
                ad_number = 0
            request_body = {
                "bucket_name": bucket,
                "object_name": resource,
                "ad_number": ad_number
            }
            r = requests.post(url = f'{airflow_api_endpoint}/dags/{airflow_dag_id}/dagRuns', headers={'Content-Type':'application/json'}, json={'conf': request_body}, auth=(airflow_username, airflow_password))
            logging.getLogger().info(f'Response status: {r.status_code}')
            logging.getLogger().info(f'Response: {r.json()}')
        else:
            logging.getLogger().info(f'Unsupported file format: {file_extension}')
    except ValueError as ex:
        logging.getLogger().error('error parsing json payload: ' + str(ex))
        logging.getLogger().error(traceback.print_exc())
    except Exception as ex:
        logging.getLogger().error('Unexpected exception occured: '+ str(ex))
        logging.getLogger().error(traceback.print_exc())


    return response.Response(
        ctx, response_data=json.dumps(
            {"message": "Request received."}),
        headers={"Content-Type": "application/json"}
    )